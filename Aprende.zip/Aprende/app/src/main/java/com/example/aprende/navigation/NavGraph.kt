package com.example.aprende.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import com.example.aprende.ui.screens.auth.LoginScreen
import com.example.aprende.ui.screens.auth.RegisterScreen
import com.example.aprende.ui.screens.home.HomeScreen
import com.example.aprende.ui.screens.welcome.WelcomeScreen

sealed class Screen(val route: String) {
    object Welcome  : Screen("welcome")
    object Login    : Screen("login")
    object Register : Screen("register")
    object Home     : Screen("home")
    object Materias : Screen("materias")
    object Tareas   : Screen("tareas")
    object Retos    : Screen("retos")
    object Perfil   : Screen("perfil")
}

@Composable
fun NavGraph(navController: NavHostController) {
    NavHost(
        navController    = navController,
        startDestination = Screen.Welcome.route
    ) {
        composable(Screen.Welcome.route)  { WelcomeScreen(navController) }
        composable(Screen.Login.route)    { LoginScreen(navController) }
        composable(Screen.Register.route) { RegisterScreen(navController) }
        composable(Screen.Home.route)     { HomeScreen(navController) }
        // Próximamente:
        // composable(Screen.Materias.route) { MateriasScreen(navController) }
        // composable(Screen.Tareas.route)   { TareasScreen(navController) }
        // composable(Screen.Retos.route)    { RetosScreen(navController) }
        // composable(Screen.Perfil.route)   { PerfilScreen(navController) }
    }
}